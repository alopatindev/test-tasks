This folder contains an application deployed using the Marmalade SDK.

    Application : MiniGame
        Version : 0.0.1
    SDK Version : 6.0.5 [319368]
  Date Deployed : Sun Aug 05 17:52:22 2012
      Target OS : win32 (Windows (Beta))
  Configuration : Release
