This folder contains an application deployed using the Marmalade SDK.

    Application : Shark
        Version : 0.0.1
    SDK Version : 6.0.6 [323198]
  Date Deployed : Tue Aug 28 15:17:37 2012
      Target OS : win32 (Windows (Beta))
  Configuration : Release
